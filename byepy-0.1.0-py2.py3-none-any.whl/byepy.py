"""
ByePy - Python facilities for the ByePy dialect
Copyright (C) 2022  Tim Fischer

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""

from __future__ import annotations

import re
from contextlib import contextmanager
from dataclasses import fields, is_dataclass
import decimal
from typing import TypeVar, Any, Callable, Generic, Literal, Iterator, Dict, List
from inspect import getsource
from operator import or_
import json

import psycopg2
from psycopg2.extras import Json, CompositeCaster
from psycopg2.extensions import (
    ISQLQuote,
    AsIs,
    register_adapter,
    adapt,
    new_type,
    new_array_type,
    register_type,
    string_types,
)


__version__ = "0.1.0"

__all__ = (
    "connect",
    "SQL",
    "DO",
    "DEFINE",
    "register_composite",
    "register_enum",
    "coalesce",
)


T = TypeVar("T")
TYPE = TypeVar("TYPE", bound=type)
PARAM = re.compile(r"(?<!\$)\$(\d+)")
_CON: psycopg2.connection | None = None
_CUR: psycopg2.cursor
register_adapter(dict, Json)


# Since decimal and floats don't like each other in python
# this line is included to make all the annoying errors
# simply disappear...
decimal.Decimal = float  # type: ignore


def connect(auth: str):
    """Set global database connection.

    >>> connect("host=localhost dbname=postgres")

    :param auth: auth string defining the connection/authentication
    :type auth: str
    """
    global _CON, _CUR
    _CON = psycopg2.connect(auth)
    _CUR = _CON.cursor()


@contextmanager
def _cursor() -> psycopg2.cursor:  # type: ignore
    global _CON, _CUR
    if _CON is None:
        raise RuntimeError("Connection not configured!")
    yield _CUR


def DO(src: str, params: list | None = None):
    """Perform arbitrary sql code using the global connection.

    ⚠  Does not return any results!

    :param src: the code to perform
    :type src: str
    :param params: code parameters, defaults to None
    :type params: list | None
    """
    with _cursor() as cur:
        query, _params = _transpile_parameterised_sql(src, params)
        cur.execute(query, _params or None)
    _CON.commit()


def DEFINE(src: str):
    """Strictly unparameterised version of DO.

    This is meant for DDL code. The compiler will look
    for calls to this function and assume things based
    on the included SQL source.

    :param src: the code to execute
    :type src: str
    """
    DO(src)


def _transpile_parameterised_sql(
    query: str, params: list | None = None
) -> tuple[str, dict[str, Any]]:
    _params = {}
    if params is not None:
        if max(map(int, PARAM.findall(query))) > len(params):
            raise ValueError("No enough parameters!")
        query = PARAM.sub(r"%(\1)s", query.replace("%", "%%"))
        _params = {str(i + 1): p for i, p in enumerate(params)}
    return query, _params


_PREPARED_STATEMENTS: Dict[str, int] = {}
SQL_CALLS: int = 0


def SQL(query: str, params: list | None = None) -> T | None:
    """Perform a scalar query using the global connection.

    >>> SQL("SELECT 1")
    1
    >>> SQL("SELECT $1", [10])
    10
    >>> SQL("SELECT $1 <> $2 AND $1 % 2 = 0", [1, 20])
    False

    :param query: the query to perform
    :type query: str
    :param params: query parameters, defaults to None
    :type params: list | None
    :return: the query result
    """
    global _PREPARED_STATEMENTS, SQL_CALLS
    SQL_CALLS += 1
    with _cursor() as cur:
        if query not in _PREPARED_STATEMENTS:
            cur.execute(f"PREPARE stmt{len(_PREPARED_STATEMENTS)} AS {query}")
            _PREPARED_STATEMENTS[query] = stmt_id = len(_PREPARED_STATEMENTS)
        else:
            stmt_id = _PREPARED_STATEMENTS[query]
        str_params = f"({','.join('%s' for _ in params)})" if params else ""
        cur.execute(f"EXECUTE stmt{stmt_id}" + str_params, params)
        return r[0] if (r := cur.fetchone()) is not None else None


def register_composite(cls: TYPE) -> TYPE:
    """Register a dataclass as the python representation of a postgres composite type.

    ⚠  The given classes name must match the name of an existing
       composite type in the database!

    >>> DEFINE("CREATE TYPE test AS (x int, y int, s text)")
    >>> @register_composite
    ... @dataclass
    ... class Test:
    ...     x: int
    ...     y: int
    ...     s: str
    ...
    >>> SQL("SELECT (1,2,'3') :: test")
    Test(x=1, y=2, s='3')
    >>> SQL("SELECT ($1 :: test).x", [_])
    1

    :param cls: dataclass to register
    :type cls: type
    :returns: the given dataclass (enables decorator use!)
    :rtype: type
    """
    if not is_dataclass(cls):
        raise TypeError("Composite classes must be dataclasses!")

    table_name = cls.__name__.lower()

    class Caster(CompositeCaster):
        def make(self, values: List[Any]) -> TYPE:
            return cls(**dict(zip(self.attnames, values)))

    with _cursor() as cur:
        C = Caster._from_db(table_name, cur)  # type: ignore

    for f in fields(cls):  # type: ignore
        attr = f.name
        if attr not in C.attnames:
            raise TypeError(f"Column {attr!r} ∉ {str(set(C.attnames))}!")
        if C.atttypes[C.attnames.index(attr)] not in string_types:
            raise RuntimeError(f"Type of column {attr!r} not registered!")

    def _adapt(inst: TYPE) -> ISQLQuote:
        return AsIs(  # type: ignore
            "ROW("
            + ",".join(
                adapt(getattr(inst, attr)).getquoted().decode("utf-8")
                for attr in C.attnames
            )
            + ") :: "
            + table_name
        )

    register_adapter(cls, _adapt)
    register_type(C.typecaster)
    register_type(C.array_typecaster)

    return cls


def register_enum(name: str, L: Type[Literal]):
    """Register a literal type as the python representation of a postgres enum.

    ⚠  This isn't necessary to ensure correctness at runtime,
       it only ensures that python type annotations correctly
       match the SQL types they describe.

    >>> DEFINE("CREATE TYPE test AS ENUM ('a', 'b', 'c');")
    >>> test = Literal['a', 'b', 'c']
    >>> register_enum("test", test)
    >>> SQL("SELECT 'a' :: test")
    'a'
    >>> SQL("SELECT 'b' :: test == $1", [_])
    False

    :param cls: literal type to register
    :type cls: type
    """
    if not all(isinstance(s, str) for s in L.__args__):
        raise TypeError("Enum values must be strings!")
    with _cursor() as cur:
        cur.execute(
            """
            SELECT pg_type.oid, typarray, enumlabel
            FROM   pg_type
            JOIN   pg_enum ON enumtypid = pg_type.oid
            WHERE  typcategory = 'E'
            AND    typname = %s
            """,
            [name],
        )
        recs = cur.fetchall()
        if not recs:
            raise ValueError(f"Could not find enum with name {name!r} in the database!")

        oid, arr_oid = recs[0][:-1]
        db_labels = {l for *_, l in recs}
        py_labels = set(L.__args__)
        if py_labels != db_labels:
            raise TypeError(
                f"Mismatch in enum label defintions!\n{py_labels} ≠ {db_labels}"
            )

        def adapt(v: str, cur: psycopg2.cursor) -> str:
            return v

        τ = new_type((oid,), name, adapt)
        τs = new_array_type((arr_oid,), name + "ARRAY", τ)
        register_type(τ)
        register_type(τs)


def to_compile(f: T) -> T:
    """Decorator to mark a compilation source."""
    src = getsource(f)
    # 1. compile to UDF in file
    # 2. use DO to place the UDF in the DB
    # 3. construct function that *just* calls said UDF
    return f


def coalesce(root, alternative):
    return root or alternative
